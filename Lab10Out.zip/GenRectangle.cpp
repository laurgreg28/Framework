//Name: Lauren Gregory
//Assignment: Lab10Out
//Description: ....
#include <iostream>
#include "GenRectangle.h"
#include "graph1.h"
#include <cmath>

GenRectangle::GenRectangle()
{
	//
}

GenRectangle::GenRectangle(GenPoint ul, GenPoint lr, Color c) : Quadrilateral(ul, GenPoint(lr.getX(), ul.getY()), lr, GenPoint(ul.getX(), lr.getY()), c)
{
	//
}
void GenRectangle::setPoints(GenPoint ul, GenPoint lr)
{
	a.setPoint(ul.getX(), ul.getY());
	b.setPoint(lr.getX(), ul.getY());
	c.setPoint(lr.getX(), lr.getY());
	d.setPoint(ul.getX(), lr.getY());	

	Quadrilateral::setPoints(a, b, c, d);
}

double GenRectangle::getArea()
{
	double area = 0.0;
	double l = c.getY() - b.getY();
	double w = b.getX() - a.getX();
	area = l * w;

	return area;
}

void GenRectangle::print()
{
	Quadrilateral::draw();
	Quadrilateral::print();
	gout << setPos(0, 15) << ::setColor(0, 255, 0) << "Rectangle Information" << endg;
	gout << setPos(0, 25) << ::setColor(0, 255, 0) << " Area: " << GenRectangle::getArea() << endg;
}