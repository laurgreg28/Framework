//Name: Lauren Gregory
//Assignment: Lab10Out
//Description: ....

#include <iostream>
#include "RightTriangle.h"
#include "graph1.h"

RightTriangle::RightTriangle() 
{
	//
}

RightTriangle::RightTriangle(GenPoint vertex, int height, int base, Color color) : Triangle(vertex, b, c, color)
{
	//
}

void RightTriangle::print()
{
	Triangle::draw();
	Triangle::print();
	gout << setPos(0, 15) << ::setColor(0, 255, 0) << "Right Triangle" << endg;
}