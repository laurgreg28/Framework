//Name: Lauren Gregory
//Assignment: Lab10Out
//Description: ....

#include <iostream>
#include "Trapezoid.h"
#include "graph1.h"

Trapezoid::Trapezoid()
{
	//
}

Trapezoid::Trapezoid(GenPoint a, GenPoint b, GenPoint c, GenPoint d, Color color) : Quadrilateral(a, b, c, d, color)
{
	//
}

void Trapezoid::setPoints(GenPoint a, GenPoint b, GenPoint c, GenPoint d)
{
	Quadrilateral::setPoints(a,b,c,d);
}

double Trapezoid::getArea()
{
	double area = 0.0;
	double b1 = b.getX() - a.getX();
	double b2 = c.getX() - d.getX();
	double height = c.getY() - a.getY();
	area = 0.5 * (b1 + b2) * height;
	return area;
}

void Trapezoid::print()
{
	Quadrilateral::draw();
	Quadrilateral::print();
	gout << setPos(0, 15) << ::setColor(0, 255, 0) << "Trapezoid Information" << endg;
	gout << setPos(0, 25) << ::setColor(0, 255, 0) << " Area: " << Trapezoid::getArea() << endg;
}